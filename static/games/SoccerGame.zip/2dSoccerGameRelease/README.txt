⚽ SOCCER GAME 🥅

created by: allein 🎮

I️ HOW TO PLAY

player 1:
1 ⬆️ up: arrow up
2 ⬇️ down: arrow down
3 ⬅️ left: arrow left
4 ➡️ right: arrow right
5 ⚡ kick: space

player 2:
i ⬆️ up: w
ii ⬇️ down: s
iii ⬅️ left: a
iv ➡️ right: d
v ⚡ kick: space

goal: score more ⚽ than your opponent

II️ FEATURES

1 2-player local multiplayer
2 🏃‍♂️ smooth player movement
3 🥅 moving goalkeepers
4 ⚽ ball resets if out of bounds
5 🎵 background music
6 🎨 fun colorful sprites

III️ HOW TO START

1 download & unzip 📦
2 double-click soccergame.exe 💻
3 start kicking and scoring 🥳

IV️ TIPS

1 play with a friend for max fun 👯
2 keyboard required ⌨️

V️ CREDITS

1 made by allein 💖
2 sprites & music: free / personal use